﻿using MediatR;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Queries
{
    public record Getiphonedataquery:IRequest<List<Iphonemobile>>;
    
}
