﻿using MediatR;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Queries
{
    public record Getanroidmonilequery:IRequest<List<Anroidmobile>>;
}
