﻿using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;
using milestonepracticecqrs.DataAccess;
using milestonepracticecqrs.DataAccess.Interfaces;
using milestonepracticecqrs.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using JwtRegisteredClaimNames = Microsoft.IdentityModel.JsonWebTokens.JwtRegisteredClaimNames;

namespace milestonepracticecqrs.Repository
{
    public class userrepositrory : IUser
    {
        private readonly MobilesContext context;
        private readonly IConfiguration configuration;
        public userrepositrory(MobilesContext context, IConfiguration configuration)
        {
            this.context = context;
            this.configuration = configuration;
        }
        private string GetToken(User user)
        {
            // extra layer of protection using claims
            var tokenClaims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                new Claim("UserId", user.Userid.ToString())

            };



            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:key"]));
            var signin = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(configuration["Jwt:Issuer"],
                configuration["jwt:Audience"],
                tokenClaims,
                expires: DateTime.Now.AddMinutes(24000),
                signingCredentials: signin);

            return new JwtSecurityTokenHandler().WriteToken(token);

        }
        public UserDTO Loginid(UserDTO userDTO)
        {

            try
            {
                if (userDTO != null)
                {
                    var userExist = context.Users.Where(u => u.Email == userDTO.Email && u.Password == userDTO.Password).FirstOrDefault();

                    if (userExist != null)
                    {
                        userDTO.Message = "Login Successful!";
                        userDTO.Token = GetToken(userExist);
                        

                        return userDTO;
                    }
                    else
                    {
                        throw new Exception("User doesn't exist");
                    }
                }
                else
                {
                    throw new Exception("Please enter user details!");
                }
            }
            catch (Exception loginException)
            {
                throw new Exception(loginException.Message);
            }
        }

        public UserDTO RegisterUser(UserDTO userDTO)
        {
            throw new NotImplementedException();
        }
    }
}
