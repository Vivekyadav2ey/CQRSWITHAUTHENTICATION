﻿using milestonepracticecqrs.DataAccess;
using milestonepracticecqrs.DataAccess.Interfaces;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Repository
{
    public class Iphonerepository : IIphonemobile
    {
        private readonly MobilesContext _context;
        public Iphonerepository(MobilesContext context)
        {
            _context = context;
        }
        public List<Iphonemobile> Addiphonelist(Iphonemobile phonemobile)
        {
            try
            {
                _context.Iphonemobiles.Add(phonemobile);
            }
            catch (Exception e) 
            {
                Console.WriteLine(e.ToString());

            }

              _context.SaveChanges();
            return _context.Iphonemobiles.ToList();

        }

        public string Deleteiphonelist(int Mno)
        {
            var iphonemnos = _context.Iphonemobiles.Find(Mno);
            try
            {
                if (iphonemnos != null)
                {
                    _context.Iphonemobiles.Remove(iphonemnos);
                    _context.SaveChanges();
                    return "Success";
                }
                else
                {
                    return "Not Found";
                }
            }
            catch(IndexOutOfRangeException e)
            {
                return e.ToString();
            }
        }

        public List<Iphonemobile> GetPhonemobileList()
        {
            return _context.Iphonemobiles.ToList();
        }

        public List<Iphonemobile> UpdateIphonelist(Iphonemobile phonemobile)
        {
            var iphonemno= _context.Iphonemobiles.Find(phonemobile.Mno);
            if (iphonemno != null)
            {
                phonemobile.Version = iphonemno.Version;
                _context.SaveChanges();
            }
            return _context.Iphonemobiles.ToList();
        }
    }
}
