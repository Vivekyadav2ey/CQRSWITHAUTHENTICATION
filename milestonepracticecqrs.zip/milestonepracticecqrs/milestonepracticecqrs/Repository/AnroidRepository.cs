﻿using milestonepracticecqrs.DataAccess;
using milestonepracticecqrs.DataAccess.Interfaces;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Repository
{
    public class AnroidRepository:IAnroidmobile
    {
        private readonly MobilesContext _context;
        public AnroidRepository(MobilesContext mobilesContext) 
        { 
            _context = mobilesContext;

        }

        public List<Anroidmobile> Createaanroidlist(Anroidmobile anroidmobile)
        {
            try
            {
                _context.Anroidmobiles.Add(anroidmobile);

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            _context.SaveChanges();
            return _context.Anroidmobiles.ToList();
        }

      
        public string Deletetheanroiddata(int id)
        {
            var anroidid=_context.Anroidmobiles.Find(id);
            try
            {
                if (anroidid != null)
                {
                    _context.Anroidmobiles.Remove(anroidid);
                    _context.SaveChanges();
                    return "Success";
                }
                else
                {
                    return "not found";
                }  
            }
            catch(IndexOutOfRangeException e)
            {
                return e.ToString();
            }
        }

        public List<Anroidmobile> GetAnroidmobiles()
        {
            return _context.Anroidmobiles.ToList() ;
        }

        public List<Anroidmobile> Updateaanroidlist(Anroidmobile anroidmobile)
        {
            var anroidid=_context.Anroidmobiles.Find(anroidmobile.Id);
            if(anroidid!=null)
            {
                anroidmobile.Category = anroidid.Category;
                anroidmobile.City = anroidid.City;
                _context.SaveChanges();
            }
            return _context.Anroidmobiles.ToList();
        }

     

        List<Anroidmobile> IAnroidmobile.GetAnroidmobiles()
        {
            throw new NotImplementedException();
        }
    }
}
