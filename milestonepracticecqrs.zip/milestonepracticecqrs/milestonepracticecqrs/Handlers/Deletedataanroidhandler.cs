﻿using MediatR;
using milestonepracticecqrs.Commands;
using milestonepracticecqrs.DataAccess.Interfaces;

namespace milestonepracticecqrs.Handlers
{
    public class Deletedataanroidhandler : IRequestHandler<deleteadataanroidcommand, string>
    {
        private readonly IAnroidmobile _anroidmobile;
        public Deletedataanroidhandler(IAnroidmobile anroidmobile)
        {
            _anroidmobile = anroidmobile;
        }
        public async Task<string> Handle(deleteadataanroidcommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(_anroidmobile.Deletetheanroiddata(request.id));
        }
    }
}
