﻿using MediatR;
using milestonepracticecqrs.DataAccess.Interfaces;
using milestonepracticecqrs.Models;
using milestonepracticecqrs.Queries;

namespace milestonepracticecqrs.Handlers
{
    public class Getadataanroidhandler : IRequestHandler<Getanroidmonilequery, List<Anroidmobile>>
    {
        private readonly IAnroidmobile _anroidmobile;
        public Getadataanroidhandler(IAnroidmobile anroidmobile)
        {
            _anroidmobile=anroidmobile;
        }
        public async Task<List<Anroidmobile>> Handle(Getanroidmonilequery request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(_anroidmobile.GetAnroidmobiles());
        }
    }
}
