﻿using MediatR;
using milestonepracticecqrs.Commands;
using milestonepracticecqrs.DataAccess.Interfaces;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Handlers
{
    public class loginidhandler : IRequestHandler<loginusercommand, UserDTO>
    {
        private readonly IUser user;
        public loginidhandler(IUser user)
        {
            this.user = user;
        }
        public async Task<UserDTO> Handle(loginusercommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(user.Loginid(request.user));
        }
    }
}
