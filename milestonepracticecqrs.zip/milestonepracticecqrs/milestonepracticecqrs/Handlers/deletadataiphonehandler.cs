﻿using MediatR;
using milestonepracticecqrs.Commands;
using milestonepracticecqrs.DataAccess.Interfaces;

namespace milestonepracticecqrs.Handlers
{
    public class deletadataiphonehandler : IRequestHandler<Deletedataiphonecommand, string>
    {
        private readonly IIphonemobile _iphonemobile;
        public deletadataiphonehandler(IIphonemobile iphonemobile)
        {
            _iphonemobile = iphonemobile;

        }
        public async Task<string> Handle(Deletedataiphonecommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(_iphonemobile.Deleteiphonelist(request.Mno));
        }
    }
}
