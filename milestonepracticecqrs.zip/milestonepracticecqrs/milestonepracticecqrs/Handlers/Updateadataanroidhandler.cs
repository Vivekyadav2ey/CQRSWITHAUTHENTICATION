﻿using MediatR;
using milestonepracticecqrs.Commands;
using milestonepracticecqrs.DataAccess.Interfaces;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Handlers
{
    public class Updateadataanroidhandler : IRequestHandler<Updateadataanroidcommand, List<Anroidmobile>>
    {
        private readonly IAnroidmobile _anroidmobile;

        public Updateadataanroidhandler(IAnroidmobile anroidmobile)
        {
            _anroidmobile = anroidmobile;
        }
        public async Task<List<Anroidmobile>> Handle(Updateadataanroidcommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(_anroidmobile.Updateaanroidlist(request.Anroidmobile));
        }
    }
}
