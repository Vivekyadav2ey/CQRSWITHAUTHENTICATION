﻿using MediatR;
using milestonepracticecqrs.Commands;
using milestonepracticecqrs.DataAccess.Interfaces;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Handlers
{
    public class Updateiphonedatahandler : IRequestHandler<updatedataiphonecommand, List<Iphonemobile>>
    {
        private readonly IIphonemobile _iphonemobile;
        public Updateiphonedatahandler(IIphonemobile phonemobile)
        {
            _iphonemobile = phonemobile;
        }
        public async Task<List<Iphonemobile>> Handle(updatedataiphonecommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(_iphonemobile.UpdateIphonelist(request.Iphonemobile));
        }
    }
}
