﻿using MediatR;
using milestonepracticecqrs.DataAccess.Interfaces;
using milestonepracticecqrs.Models;
using milestonepracticecqrs.Queries;

namespace milestonepracticecqrs.Handlers
{
    public class Getiphonedatahandler : IRequestHandler<Getiphonedataquery, List<Iphonemobile>>
    {
        private readonly IIphonemobile _iphonemobile;
        public Getiphonedatahandler(IIphonemobile iphonemobile) 
        {
            _iphonemobile = iphonemobile;

        }

        public async Task<List<Iphonemobile>> Handle(Getiphonedataquery request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(_iphonemobile.GetPhonemobileList());
        }
    }
}
