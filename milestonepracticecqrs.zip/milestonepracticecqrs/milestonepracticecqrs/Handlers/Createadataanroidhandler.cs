﻿using MediatR;
using milestonepracticecqrs.Commands;
using milestonepracticecqrs.DataAccess.Interfaces;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Handlers
{
    public class Createadataanroidhandler : IRequestHandler<createaanroiddatacommand, List<Anroidmobile>>
    {
        private readonly IAnroidmobile _anroidmobile;
        public Createadataanroidhandler(IAnroidmobile anroidmobile) 
        {
            _anroidmobile = anroidmobile;
        }

        public async Task<List<Anroidmobile>> Handle(createaanroiddatacommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(_anroidmobile.Createaanroidlist(request.Anroidmobile));
        }
    }
}
