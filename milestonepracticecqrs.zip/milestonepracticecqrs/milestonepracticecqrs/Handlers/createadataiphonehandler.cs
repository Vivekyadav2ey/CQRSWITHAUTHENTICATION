﻿using MediatR;
using milestonepracticecqrs.Commands;
using milestonepracticecqrs.DataAccess.Interfaces;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Handlers
{
    public class createadataiphonehandler : IRequestHandler<createadataiphonecommand, List<Iphonemobile>>
    {
        private readonly IIphonemobile _iphonemobile;
        public createadataiphonehandler(IIphonemobile iphonemobile)
        {
            _iphonemobile= iphonemobile;
        }
        public async Task<List<Iphonemobile>> Handle(createadataiphonecommand request, CancellationToken cancellationToken)
        {
            return await Task.FromResult(_iphonemobile.Addiphonelist(request.Iphonemobile));
        }
    }
}
