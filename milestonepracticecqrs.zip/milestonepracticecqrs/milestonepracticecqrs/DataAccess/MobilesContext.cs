﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.DataAccess;

public partial class MobilesContext : DbContext
{
    public MobilesContext()
    {
    }

    public MobilesContext(DbContextOptions<MobilesContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Anroidmobile> Anroidmobiles { get; set; }

    public virtual DbSet<Iphonemobile> Iphonemobiles { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) { }
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
//        => optionsBuilder.UseSqlServer("server=IN3291558W1\\SQLEXPRESS;database=Mobiles;trusted_connection=true;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Anroidmobile>(entity =>
        {
            entity.ToTable("Anroidmobile");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Category)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("category");
            entity.Property(e => e.City)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("city");
            entity.Property(e => e.Mobilename)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("mobilename");
        });

        modelBuilder.Entity<Iphonemobile>(entity =>
        {
            entity.HasKey(e => e.Mno);

            entity.ToTable("Iphonemobile");

            entity.Property(e => e.Mno).ValueGeneratedNever();
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("type");
            entity.Property(e => e.Version)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("version");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("user");

            entity.Property(e => e.Userid).HasColumnName("userid");
            entity.Property(e => e.Designation)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("designation");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("email");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.Password)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("password");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
