﻿using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.DataAccess.Interfaces
{
    public interface IAnroidmobile
    {
        // to read the anroid data
        public List<Anroidmobile> GetAnroidmobiles();
        // to create the anroid list
        public List<Anroidmobile> Createaanroidlist(Anroidmobile anroidmobile);
        // to update a anroid list
        public List<Anroidmobile> Updateaanroidlist(Anroidmobile anroidmobile);
        //to delete the anroid data
        public string Deletetheanroiddata(int id);
    }
}
