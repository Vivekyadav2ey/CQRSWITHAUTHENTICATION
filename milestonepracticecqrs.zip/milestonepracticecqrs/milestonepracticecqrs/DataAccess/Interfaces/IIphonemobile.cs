﻿using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.DataAccess.Interfaces
{
    public interface IIphonemobile
    {
        //to read the data
        public List<Iphonemobile> GetPhonemobileList();
        // to create tha data
        public List<Iphonemobile> Addiphonelist(Iphonemobile phonemobile);
        //to update the Iphone list
        public List<Iphonemobile> UpdateIphonelist(Iphonemobile phonemobile);

        public string Deleteiphonelist(int Mno);

    }
}
