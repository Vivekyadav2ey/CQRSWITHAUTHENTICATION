﻿using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.DataAccess.Interfaces
{
    public interface IUser
    {
        public UserDTO Loginid(UserDTO userDTO);
        public UserDTO RegisterUser(UserDTO userDTO);

    }
}
