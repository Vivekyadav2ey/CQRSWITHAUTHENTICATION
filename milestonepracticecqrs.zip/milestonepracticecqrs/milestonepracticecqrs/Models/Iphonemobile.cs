﻿using System;
using System.Collections.Generic;

namespace milestonepracticecqrs.Models;

public partial class Iphonemobile
{
    public int Mno { get; set; }

    public int Id { get; set; }

    public string? Version { get; set; }

    public string? Type { get; set; }
}
