﻿using System;
using System.Collections.Generic;

namespace milestonepracticecqrs.Models;

public partial class Anroidmobile
{
    public int Id { get; set; }

    public string? Mobilename { get; set; }

    public string? Category { get; set; }

    public string? City { get; set; }
}
