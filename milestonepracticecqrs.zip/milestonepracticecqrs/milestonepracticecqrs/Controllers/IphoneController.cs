﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using milestonepracticecqrs.Commands;
using milestonepracticecqrs.DataAccess.Interfaces;
using milestonepracticecqrs.Models;
using milestonepracticecqrs.Queries;

namespace milestonepracticecqrs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class IphoneController : ControllerBase
    {
        private readonly IMediator mediator;
        public IphoneController(IMediator mediator)
        {
            this.mediator = mediator;
        }
        [HttpGet]
        [Route("To read a record")]
        public async Task<IActionResult> Getalliphonedetails()
        {
            var iphoneinfo = await mediator.Send(new Getiphonedataquery());
            return Ok(iphoneinfo);
        }
        [HttpPost]
        [Route("To add the details")]
        public async Task<IActionResult> Toaddthedetails([FromBody] Iphonemobile iphonemobile)
        {
            await mediator.Send(new createadataiphonecommand(iphonemobile));
            return StatusCode(201);
        }
        [HttpPut]
        [Route("To update the details")]
        public async Task<IActionResult> Toupdatetheiphonedetails([FromBody] Iphonemobile iphonemobile)
        {
            await mediator.Send(new updatedataiphonecommand(iphonemobile));
            return Ok(iphonemobile);
        }
        [HttpDelete]
        [Route("to delete")]
        public async Task<IActionResult> Deletetheiphonedetails(int Mno)
        {
            await mediator.Send(new Deletedataiphonecommand(Mno));
            return StatusCode(201);
        }

    }
}
