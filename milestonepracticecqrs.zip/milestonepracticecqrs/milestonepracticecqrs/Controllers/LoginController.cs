﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using milestonepracticecqrs.Commands;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IMediator mediator;
        public LoginController(IMediator mediator)
        {
            this.mediator = mediator;
        }
        [HttpPost]
        [Route("Loginuser")]
        public async Task<ActionResult> Loginuser1(UserDTO user)
        {
            var user1=await mediator.Send(new loginusercommand(user));
            return Ok(user1);
        }
    }
}
