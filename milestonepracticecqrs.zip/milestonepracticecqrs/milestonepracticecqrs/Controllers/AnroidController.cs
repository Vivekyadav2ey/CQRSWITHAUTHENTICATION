﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using milestonepracticecqrs.Commands;
using milestonepracticecqrs.Models;
using milestonepracticecqrs.Queries;

namespace milestonepracticecqrs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AnroidController : ControllerBase
    {
        private IMediator mediator;
        public AnroidController(IMediator mediator)
        {
            this.mediator = mediator;
        }
        [HttpGet]
        [Route("to read a anroid data")]
        public async Task<IActionResult> Getallanroiddetails()
        {
            var anroidinfo = await mediator.Send(new Getanroidmonilequery());
            return Ok(anroidinfo);
        }
        [HttpPost]
        [Route("To add detsils in anroid list")]
        public async Task<IActionResult> Adddetailsinanroid([FromBody] Anroidmobile anroidmobile)
        {
            await mediator.Send(new createaanroiddatacommand(anroidmobile));
            return StatusCode(201);
        }
        [HttpPut]
        [Route("to update data in anroid")]
        public async Task<IActionResult> Updatedatainanroid([FromBody] Anroidmobile anroidmobile)
        {
            await mediator.Send(new Updateadataanroidcommand(anroidmobile));
            return Ok(anroidmobile);
        }
        [HttpDelete]
        public async Task<IActionResult> deletethedatainanroid(int id)
        {
            await mediator.Send(new deleteadataanroidcommand(id));
            return StatusCode(201);
        }
    }
}
