﻿using MediatR;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Commands
{
    public record createaanroiddatacommand(Anroidmobile Anroidmobile):IRequest<List<Anroidmobile>>;
}
