﻿using MediatR;

namespace milestonepracticecqrs.Commands
{
    public record Deletedataiphonecommand(int Mno):IRequest<string>;
    
}
