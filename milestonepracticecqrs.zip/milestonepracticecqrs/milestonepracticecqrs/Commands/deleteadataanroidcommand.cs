﻿using MediatR;

namespace milestonepracticecqrs.Commands
{
    public record deleteadataanroidcommand(int id):IRequest<string>;
}
