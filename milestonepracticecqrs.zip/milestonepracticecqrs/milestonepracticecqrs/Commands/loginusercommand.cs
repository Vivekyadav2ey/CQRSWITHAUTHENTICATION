﻿using MediatR;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Commands
{
    public record loginusercommand(UserDTO user):IRequest<UserDTO>;
    
}
