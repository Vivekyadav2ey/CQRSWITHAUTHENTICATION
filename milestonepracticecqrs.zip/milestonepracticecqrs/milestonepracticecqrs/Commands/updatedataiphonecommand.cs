﻿using MediatR;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Commands
{
    public record updatedataiphonecommand(Iphonemobile Iphonemobile):IRequest<List<Iphonemobile>>;
    
}
