﻿using MediatR;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Commands
{
    public record createadataiphonecommand(Iphonemobile Iphonemobile):IRequest<List<Iphonemobile>>;
   
}
