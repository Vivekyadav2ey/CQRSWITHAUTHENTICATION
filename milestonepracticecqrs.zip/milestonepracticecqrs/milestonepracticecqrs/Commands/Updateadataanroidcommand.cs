﻿using MediatR;
using milestonepracticecqrs.Models;

namespace milestonepracticecqrs.Commands
{
    public record Updateadataanroidcommand(Anroidmobile Anroidmobile):IRequest<List<Anroidmobile>>;
   
}
